﻿namespace LINQ
{
    public class Gender
    {
        public Guid Id { get; set; }
        public string Sex { get; set; }
    }
}
